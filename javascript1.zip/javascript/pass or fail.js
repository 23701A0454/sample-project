
let marks=93
if(marks>33){
    console.log("pass")
}
else{
    console.log("fail")
}
