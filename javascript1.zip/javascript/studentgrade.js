console.log("assign student grades")
let marks=95
if(marks>=90 && marks<=100){
    grade="A";
}
else if(marks>=75){
    grade="B";
}
else if(marks>=60){
    grade="c";
}
else if(marks>=50){
    grade="D";
}
else{
     grade="E"
}
console.log("marks:" +marks)

console.log("marks:" +grade)


