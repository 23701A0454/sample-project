console.log("check a number is even or not")
let n=10
if(n%2==0){
    console.log("your given number is even: " ,n)
}
else{
     console.log("your given number is odd: " ,n)
}
